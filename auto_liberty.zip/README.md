# AUTO LIBERTY

Minimal Flask app (AUTO LIBERTY) - ready to deploy on Render.

Run locally:

1. python3 -m venv venv
2. source venv/bin/activate
3. pip install -r requirements.txt
4. python app.py
5. Open http://127.0.0.1:5000/

Notes:
- Uses SQLite by default (file: auto_liberty.db)
- Public (no login). If you want login, tell me and I add it.
