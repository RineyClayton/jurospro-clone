from flask import Flask, render_template, request, redirect, url_for, flash, make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os, io, csv

# Basic configuration
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'auto-liberty-dev')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///auto_liberty.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize DB
db = SQLAlchemy(app)

# Models
class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    phone = db.Column(db.String(50))
    cpf = db.Column(db.String(50))
    email = db.Column(db.String(200))
    address = db.Column(db.String(300))
    loans = db.relationship('Loan', backref='client', lazy=True)

class Loan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('client.id'), nullable=False)
    principal = db.Column(db.Float, nullable=False)
    interest_rate = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    installments = db.relationship('Installment', backref='loan', lazy=True, cascade='all, delete')

    def total_amount(self):
        return round(self.principal * (1 + (self.interest_rate or 0)/100), 2)

class Installment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    loan_id = db.Column(db.Integer, db.ForeignKey('loan.id'), nullable=False)
    number = db.Column(db.Integer, nullable=False)
    due_date = db.Column(db.Date)
    amount = db.Column(db.Float, nullable=False)
    paid = db.Column(db.Boolean, default=False)
    paid_at = db.Column(db.DateTime, nullable=True)

    def is_overdue(self):
        if self.paid:
            return False
        return datetime.utcnow().date() > self.due_date

# Auto-create DB and sample data if needed
@app.before_first_request
def setup():
    db.create_all()
    # add sample data only if no clients exist
    if Client.query.count() == 0:
        c = Client(name='João Silva', phone='11999998888', cpf='123.456.789-00', email='joao@example.com')
        db.session.add(c)
        db.session.commit()
        l = Loan(client_id=c.id, principal=1000.0, interest_rate=2.0, notes='Exemplo')
        db.session.add(l)
        db.session.commit()
        for i in range(3):
            inst = Installment(loan_id=l.id, number=i+1, due_date=(datetime.utcnow().date() + timedelta(days=30*(i+1))), amount=round(l.total_amount()/3,2))
            db.session.add(inst)
        db.session.commit()

# Routes (public - no login)
@app.route('/')
def dashboard():
    loans = Loan.query.all()
    total_principal = sum(l.principal for l in loans)
    total_amount = sum(l.total_amount() for l in loans)
    installments = Installment.query.all()
    total_to_receive = sum(it.amount for it in installments if not it.paid)
    total_overdue = sum(it.amount for it in installments if (not it.paid and it.is_overdue()))
    paid_total = sum(it.amount for it in installments if it.paid)
    upcoming = [it for it in installments if (not it.paid and (it.due_date - datetime.utcnow().date()).days <=7)]
    return render_template('dashboard.html',
                           total_principal=total_principal,
                           total_amount=total_amount,
                           total_to_receive=total_to_receive,
                           total_overdue=total_overdue,
                           paid_total=paid_total,
                           upcoming=upcoming)

@app.route('/clients')
def clients():
    clients = Client.query.order_by(Client.name).all()
    return render_template('clients.html', clients=clients)

@app.route('/clients/new', methods=['GET','POST'])
def new_client():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form.get('phone')
        cpf = request.form.get('cpf')
        email = request.form.get('email')
        address = request.form.get('address')
        c = Client(name=name, phone=phone, cpf=cpf, email=email, address=address)
        db.session.add(c)
        db.session.commit()
        return redirect(url_for('clients'))
    return render_template('new_client.html')

@app.route('/clients/<int:client_id>')
def client_detail(client_id):
    client = Client.query.get_or_404(client_id)
    return render_template('client_detail.html', client=client)

@app.route('/loans')
def loans():
    loans = Loan.query.order_by(Loan.created_at.desc()).all()
    return render_template('loans.html', loans=loans)

@app.route('/loans/new', methods=['GET','POST'])
def new_loan():
    clients = Client.query.order_by(Client.name).all()
    if request.method == 'POST':
        client_id = int(request.form['client_id'])
        principal = float(request.form['principal'])
        interest_rate = float(request.form.get('interest_rate') or 0)
        parcels = int(request.form.get('parcels') or 1)
        first_due = datetime.strptime(request.form.get('first_due'), '%Y-%m-%d').date()
        notes = request.form.get('notes')
        loan = Loan(client_id=client_id, principal=principal, interest_rate=interest_rate, notes=notes)
        db.session.add(loan)
        db.session.commit()
        total = loan.total_amount()
        per = round(total / parcels, 2)
        for i in range(parcels):
            due = first_due + timedelta(days=30*i)
            inst = Installment(loan_id=loan.id, number=i+1, due_date=due, amount=per)
            db.session.add(inst)
        db.session.commit()
        return redirect(url_for('loan_detail', loan_id=loan.id))
    return render_template('new_loan.html', clients=clients)

@app.route('/loans/<int:loan_id>')
def loan_detail(loan_id):
    loan = Loan.query.get_or_404(loan_id)
    return render_template('loan_detail.html', loan=loan)

@app.route('/installment/<int:inst_id>/pay', methods=['POST'])
def pay_installment(inst_id):
    inst = Installment.query.get_or_404(inst_id)
    inst.paid = True
    inst.paid_at = datetime.utcnow()
    db.session.commit()
    return redirect(request.referrer or url_for('dashboard'))

@app.route('/export/csv')
def export_csv():
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['Client','Loan ID','Installment #','Due Date','Amount','Paid','Paid At'])
    for it in Installment.query.join(Loan).join(Client).add_columns(Client.name, Loan.id, Installment.number, Installment.due_date, Installment.amount, Installment.paid, Installment.paid_at).all():
        row = [it[1], it[2], it[3], it[4].isoformat(), it[5], it[6].isoformat() if it[6] else '']
        cw.writerow(row)
    output = make_response(si.getvalue())
    output.headers['Content-Disposition'] = 'attachment; filename=installments.csv'
    output.headers['Content-type'] = 'text/csv'
    return output

# Simple search
@app.route('/search')
def search():
    q = request.args.get('q','')
    clients = Client.query.filter(Client.name.ilike(f'%{q}%')).all()
    loans = Loan.query.join(Client).filter(Client.name.ilike(f'%{q}%')).all()
    return render_template('clients.html', clients=clients, loans=loans)

# Run
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
